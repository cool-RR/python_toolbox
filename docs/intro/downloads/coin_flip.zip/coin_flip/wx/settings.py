# from . import widgets.state_viewer
# from . import widgets.state_creation_dialog


########### *All* of the settings in this module are optional. ################


# BIG_WORKSPACE_WIDGETS = widgets.state_viewer.StateViewer

# Widgets to show in the middle of the frame. These must be instances of
# `garlicsim_wx.widgets.workspace_widget`.
#
# This is where you usually put your main widget that displays your states.


# SMALL_WORKSPACE_WIDGETS = []

# (01.01.2011 - Still not implemented, sorry.)
#
# Small widgets to show in the frame. These must be instances of
# `garlicsim_wx.widgets.workspace_widget`.
#
# This is where you usually put small tools.


# SEEK_BAR_GRAPHS = []

# (01.01.2011 - Still not implemented, sorry.)
#
# List of scalar functions that should be shown as graphs in the seek bar.
#
# These may be either scalar state functions or scalar history functions.


# STATE_CREATION_DIALOG = widgets.state_creation_dialog
#
# Dialog for creating a root state.